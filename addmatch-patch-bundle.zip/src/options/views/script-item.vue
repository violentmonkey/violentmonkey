<template>
  <div
    ref="$root"
    class="script"
    :class="{
      disabled: !isEnabled,
      removed: isRemoved,
      error: script.error,
      focused: focused,
      hotkeys: focused && showHotkeys,
      'has-add-match': addMatchOpen,
    }"
    :tabIndex
    @focus="setScriptFocus(true)"
    @blur="setScriptFocus(false)">
    <div class="script-icon hidden-xs">
      <a :href="url" :data-hotkey="hotkeys.edit" data-hotkey-table tabIndex="-1">
        <img :src="cache.safeIcon" :data-no-icon="cache.noIcon">
      </a>
    </div>
    <!-- We disable native dragging on name to avoid confusion with exec re-ordering.
    Users who want to open a new tab via dragging the link can drag the icon. -->
    <div class="script-info-1 ellipsis">
      <a v-bind="viewTable && { draggable: false, href: url, tabIndex }"
         :data-order="isRemoved ? null : script.props.position"
         class="script-name ellipsis">
        <template v-if="(n = cache.name, m = cache.mark)">{{
          n.slice(0, m.index)}}<mark v-text="m[0]"/>{{n.slice(m.index + m[0].length)
        }}</template>
        <template v-else>{{n}}</template>
      </a>
      <div class="script-tags" v-if="canRender">
        <a
          v-for="(item, i) in cache[kTag].slice(0, 2)"
          :key="i"
          v-text="`#${item}`"
          @click.prevent="onTagClick(item)"
          :class="{ active: activeTags?.includes(item) }"
          :data-tag="item"
        ></a>
        <Dropdown v-if="cache[kTag].length > 2">
          <a>...</a>
          <template #content>
            <a
              v-for="(item, i) in cache[kTag].slice(2)"
              :key="i"
              class="dropdown-menu-item"
              v-text="`#${item}`"
              @click.prevent="onTagClick(item)"
              :class="{ active: activeTags?.includes(item) }"
              :data-tag="item"
            ></a>
          </template>
        </Dropdown>
      </div>
    </div>
    <div class="script-info flex ml-1c">
      <template v-if="canRender">
        <tooltip v-if="author" :content="i18n('labelAuthor') + script.meta.author"
                 class="script-author ml-1c hidden-sm"
                 align="end">
          <icon name="author" />
          <a
            v-if="author.email"
            class="ellipsis"
            :href="`mailto:${author.email}`"
            v-text="author.name"
            :tabIndex
          />
          <span class="ellipsis" v-else v-text="author.name" />
        </tooltip>
        <span class="version ellipsis" v-text="script.meta.version"/>
        <tooltip class="visit hidden-sm ml-1c" :content="visit.title" align="end"
                 v-if="showVisit">
          {{ visit.show }}
        </tooltip>
        <tooltip class="size hidden-sm" :content="cache.sizes" align="end">
          {{ cache.size }}
        </tooltip>
        <tooltip class="updated hidden-sm ml-1c" :content="updatedAt.title" align="end">
          {{ updatedAt.show }}
        </tooltip>
      </template>
    </div>
    <div class="script-buttons script-buttons-left">
      <template v-if="canRender">
        <tooltip :content="i18n('buttonEdit')" align="start">
          <a class="btn-ghost" :href="url" :data-hotkey="hotkeys.edit" :tabIndex>
            <icon name="code"></icon>
          </a>
        </tooltip>
        <template v-if="!isRemoved">
          <tooltip :content="labelEnable" align="start">
            <a
              class="btn-ghost"
              @click="onToggle"
              :data-hotkey="hotkeys.toggle"
              :tabIndex>
              <icon :name="isEnabled ? TOGGLE_ON : TOGGLE_OFF"/>
            </a>
          </tooltip>
          <tooltip
            :disabled="!canUpdate || script.checking"
            :content="i18n('updateScript') + ' | ' + i18nUpdateScriptForced"
            :title="!canUpdate && canUpdateDeps ? i18nUpdateScriptForced : null"
            v-on="{ contextmenu: (canUpdate || canUpdateDeps) && !script.checking && onUpdate }"
            align="start">
            <a
              class="btn-ghost"
              @click="onUpdate"
              :data-hotkey="hotkeys.update"
              :tabIndex="canUpdate ? tabIndex : -1">
              <icon name="refresh" :invert.attr="canUpdate === -1 ? '' : null" />
            </a>
          </tooltip>
          <tooltip :content="i18n('menuAddMatch')" :disabled="addMatchOpen" align="start">
            <a class="btn-ghost" :tabIndex @click="onAddMatchToggle">
              <icon name="plus"></icon>
            </a>
          </tooltip>
        </template>
        <span class="sep"></span>
        <tooltip :disabled="!description" :content="description" align="start">
          <a class="btn-ghost" :tabIndex="description ? tabIndex : -1" @click="toggleTip($event.target)">
            <icon name="info"></icon>
          </a>
        </tooltip>
        <tooltip v-for="([title, url], icon) in urls" :key="icon"
                 :disabled="!url" :content="title" align="start">
          <a
            class="btn-ghost"
            v-bind="EXTERNAL_LINK_PROPS"
            :href="url"
            :tabIndex="url ? tabIndex : -1">
            <icon :name="icon"/>
          </a>
        </tooltip>
        <!-- Using v-if to actually hide it because FF is slow to apply :not(:empty) CSS -->
        <div class="script-message" v-if="script.message" v-text="script.message"
             :title="script.error || script.message"/>
      </template>
    </div>
    <div class="script-buttons script-buttons-right">
      <template v-if="canRender">
        <tooltip :content="i18n('buttonRemove')" align="end" v-if="showRecycle || !isRemoved">
          <a class="btn-ghost" :class="{ 'btn-danger': isRemoved }" @click="onRemove" :data-hotkey="hotkeys.remove" :tabIndex>
            <icon name="trash"></icon>
          </a>
        </tooltip>
        <tooltip :content="i18n('buttonRestore')" placement="left" v-if="isRemoved">
          <a
            class="btn-ghost"
            @click="onRestore"
            :data-hotkey="hotkeys.restore"
            :tabIndex>
            <icon name="undo"></icon>
          </a>
        </tooltip>
      </template>
    </div>
    <div v-if="addMatchOpen" class="add-match-panel">
      <div class="add-match-chips" v-if="tabInfo.domain">
        <button v-for="(val, key) in tabInfo.chips" :key
                v-text="val" class="ellipsis" :title="val"
                @click="onAddMatchSave(val)"/>
      </div>
      <input v-model="matchInput" spellcheck="false"
             :placeholder="i18n('menuAddMatchPlaceholder')"
             @keypress.enter="onAddMatchSave()"
             @keydown.esc.exact.stop.prevent="addMatchOpen = false"/>
      <div class="add-match-buttons">
        <button v-text="i18n('buttonCurrentTab')" @click="onAddMatchCurrentTab"/>
        <button v-text="i18n('buttonOK')" @click="onAddMatchSave()"/>
        <button v-text="i18n('buttonClear')" @click="matchInput = ''; matchNote = ''"/>
        <button v-text="i18n('buttonCancel')" @click="addMatchOpen = false"/>
      </div>
      <div class="add-match-note" v-if="matchNote" v-text="matchNote"/>
      <details class="mb-1">
        <summary><icon name="info"/></summary>
        <small v-text="i18n('menuAddMatchHint')"/>
      </details>
    </div>
  </div>
</template>

<script>
import {
  formatTime, getLocaleString, getScriptHome, getScriptSupportUrl, i18n, sendCmdDirectly, truncateText,
} from '@/common';
import { INFERRED, kTag } from '@/common/consts';
import {
  EXTERNAL_LINK_PROPS, getActiveElement, showConfirmation, showMessage, showToast,
} from '@/common/ui';
import { isInput, keyboardService, toggleTip } from '@/common/keyboard';
import { kDescription, store, TOGGLE_OFF, TOGGLE_ON } from '../utils';

const itemMargin = 8;
const i18nUpdateScriptForced = i18n('updateScriptForced');
const visitedRecently = new Set();
const refreshVisited = () => { store.now = Date.now(); };
const scheduleRefreshVisited = () => setInterval(refreshVisited, 60e3);
const setScriptFocus = val => keyboardService.setContext('scriptFocus', val);
let visitedRecentlyInterval;
</script>

<script setup>
import { computed, reactive, ref, watch } from 'vue';
import Dropdown from 'vueleton/lib/dropdown';
import Tooltip from 'vueleton/lib/tooltip';
import Icon from '@/common/ui/icon';

const props = defineProps([
  'script',
  'visible',
  'viewTable',
  'focused',
  'hotkeys',
  'showHotkeys',
  'showVisit',
  'activeTags',
]);
const emit = defineEmits([
  'clickTag',
  'remove',
  'restore',
  'scrollDelta',
  'toggle',
  'update',
]);
const $root = ref();
const canRender = ref(props.visible);
const isEnabled = computed(() => props.script.config.enabled);
const isRemoved = computed(() => props.script.config.removed);
const showRecycle = computed(() => store.route.paths[0] === TAB_RECYCLE);
const author = computed(() => {
  const text = props.script.meta.author;
  if (!text) return;
  const matches = text.match(/^(.*?)\s<(\S*?@\S*?)>$/);
  return {
    email: matches && matches[2],
    name: matches ? matches[1] : text,
  };
});
const cache = computed(() => props.script.$cache);
const canUpdate = computed(() => props.script.$canUpdate);
const notDataUrlRe = /^(?!data:)/;
const canUpdateDeps = computed(() => {
  const { meta } = props.script;
  return meta.require.some(notDataUrlRe.test, notDataUrlRe)
    || Object.values(meta.resources).some(notDataUrlRe.test, notDataUrlRe);
});
const description = computed(() => {
  return props.script.custom[kDescription] || getLocaleString(props.script.meta, kDescription);
});
const labelEnable = computed(() => {
  return isEnabled.value ? i18n('buttonDisable') : i18n('buttonEnable');
});
const tabIndex = computed(() => {
  return props.focused ? 0 : -1;
});
const updatedAt = computed(() => {
  const { props: scrProps } = props.script;
  const lastModified = !isRemoved.value && scrProps.lastUpdated || scrProps.lastModified;
  const dateStr = lastModified && new Date(lastModified).toLocaleString();
  return lastModified ? {
    show: formatDynamicTime(scrProps, lastModified),
    title: isRemoved.value
      ? i18n('labelRemovedAt', dateStr)
      : i18n('labelLastUpdatedAt', dateStr)
  } : {};
});
const visit = computed(() => {
  const { script } = props;
  const time = script[INFERRED].visit;
  return time && props.showVisit ? {
    show: formatDynamicTime(script.props, time),
    title: new Date(time).toLocaleString() + '. ' + i18n('filterLastVisitOrderTooltip'),
  } : {};
});
const url = computed(() => `#${
  isRemoved.value ? TAB_RECYCLE : SCRIPTS}/${props.script.props.id}
`);
const urls = computed(() => ({
  home: [i18n('buttonHome'), getScriptHome(props.script)],
  question: [i18n('buttonSupport'), getScriptSupportUrl(props.script)],
}));

const emitScript = event => emit(event, props.script);
const onRemove = () => emitScript('remove');
const onRestore = () => emitScript('restore');
const onTagClick = item => emit('clickTag', item);
const onToggle = () => emitScript('toggle');
const addMatchOpen = ref(false);
const matchInput = ref('');
const matchNote = ref('');
const tabInfo = ref({});
async function onAddMatchToggle() {
  if (props.viewTable) {
    onAddMatchModal();
    return;
  }
  addMatchOpen.value = !addMatchOpen.value;
  if (addMatchOpen.value) {
    matchInput.value = '';
    matchNote.value = '';
    const res = await sendCmdDirectly('GetLastPopupDomain');
    const sub = res?.domain && `*.${res.domain}`;
    tabInfo.value = res?.domain ? {
      domain: res.domain,
      chips: { domain: res.domain, sub, tld: res.anyTld },
    } : {};
    // Default to the wildcard-subdomain form: it's almost always what's wanted,
    // and the bare-domain/TLD-wildcard forms remain one tap away as chips.
    matchInput.value = sub || '';
  }
}
async function onAddMatchModal() {
  const id = props.script.props.id;
  const initial = await sendCmdDirectly('GetLastPopupDomain');
  const message = reactive({
    text: `${cache.value.name}\n\n${i18n('menuAddMatchModal')}`,
    input: initial?.domain ? `*.${initial.domain}` : '',
    buttons: [
      {
        text: i18n('buttonCurrentTab'),
        async onClick() {
          const res = await sendCmdDirectly('GetLastPopupDomain');
          message.input = res?.domain ? `*.${res.domain}` : '';
          return false;
        },
      },
      {
        text: i18n('buttonOK'),
        async onClick(val) {
          const pattern = (val || '').trim();
          if (!pattern) return false;
          const res = await sendCmdDirectly('AddScriptMatch', { id, pattern });
          if (res.duplicate) {
            showMessage({ text: i18n('msgMatchExists') });
            return false;
          }
          showToast(i18n('msgMatchAdded', [res.pattern, truncateText(cache.value.name)]));
          return true;
        },
      },
      {
        text: i18n('buttonClear'),
        onClick() {
          message.input = '';
          return false;
        },
      },
      { text: i18n('buttonCancel'), onClick: () => true },
    ],
  });
  showMessage(message);
}
const onAddMatchCurrentTab = () => {
  if (tabInfo.value.chips?.sub) matchInput.value = tabInfo.value.chips.sub;
  matchNote.value = '';
};
const onAddMatchSave = async btn => {
  const pattern = (typeof btn === 'string' ? btn : matchInput.value).trim();
  if (!pattern) return;
  const res = await sendCmdDirectly('AddScriptMatch', { id: props.script.props.id, pattern });
  if (res.duplicate) {
    matchNote.value = i18n('msgMatchExists');
  } else {
    addMatchOpen.value = false;
    showToast(i18n('msgMatchAdded', [res.pattern, truncateText(cache.value.name)]));
  }
};
const onUpdate = async evt => {
  evt.preventDefault(); // for contextmenu
  let what = props.script;
  if (what.$canUpdate !== -1
  || await showConfirmation(i18n('confirmManualUpdate'))) {
    what = [what];
    what.force = evt.type !== 'click';
    emit('update', what);
  }
};
/**
 * @param {VMScript['props']} scriptProps
 * @param {number} time
 * @return {string}
 */
function formatDynamicTime({ id }, time) {
  time = store.now - time;
  if (time < 24 * 3600e3) {
    visitedRecently.add(id);
    visitedRecentlyInterval ??= scheduleRefreshVisited();
  } else {
    visitedRecently.delete(id);
    if (visitedRecentlyInterval && !visitedRecently.size) {
      visitedRecentlyInterval = clearInterval(refreshVisited);
    }
  }
  return formatTime(Math.max(0, time));
}

watch(() => props.visible, visible => {
  // Leave it if the element is already rendered
  if (visible) canRender.value = true;
});

watch(() => props.focused, (value, prevValue) => {
  const $el = $root.value;
  if (value && !prevValue && $el) {
    const rect = $el.getBoundingClientRect();
    const pRect = $el.parentNode.getBoundingClientRect();
    let delta = 0;
    if (rect.bottom > pRect.bottom - itemMargin) {
      delta += rect.bottom - pRect.bottom + itemMargin;
    } else if (rect.top < pRect.top + itemMargin) {
      delta -= pRect.top - rect.top + itemMargin;
    }
    if (!isInput(getActiveElement())) {
      // focus without scrolling, then scroll smoothly
      $el.focus({ preventScroll: true });
    }
    emit('scrollDelta', delta);
  }
});
</script>

<style>
@import '../utils/dragging.css';

$rem: 14px;
// SVG viewport (200px) * .icon width (1rem = 14px) * attenuation factor
$strokeWidth: calc(200px / 14 * .7);
// The icon should use the real size we generate in `dist` to ensure crispness
$iconSize: 38px;
$iconSizeSmaller: 32px;
$actionIconSize: calc(2 * $rem);

$nameFontSize: $rem;

$itemLineHeight: 1.5;
$itemMargin: 8px;
$itemPadT: 12px;
$itemPadB: 5px;
$itemHeight: calc(
  $nameFontSize * $itemLineHeight +
  $actionIconSize + 2px /* icon borders */ +
  $itemPadT + $itemPadB + 2px /* item borders */
);

$removedItemPadB: 10px;
$removedItemHeight: calc(
  $actionIconSize + 2px /* icon borders */ +
  $itemPadT + $removedItemPadB + 2px /* item borders */
);

.script {
  position: relative;
  display: grid;
  grid-template-columns: $iconSize 1fr auto;
  margin: $itemMargin 0 0 $itemMargin;
  padding: $itemPadT 10px $itemPadB;
  border: 1px solid var(--fill-3);
  border-radius: .3rem;
  transition: transform .25s;
  .touch & {
    transition: none;
  }
  @media (prefers-reduced-motion: reduce) {
    transition: none;
  }
  background: var(--bg);
  width: calc((100% - $itemMargin) / var(--num-columns) - $itemMargin);
  height: $itemHeight;
  &.has-add-match {
    height: auto;
  }
  &:hover {
    border-color: var(--fill-5);
  }
  &.disabled,
  &.removed {
    background: var(--fill-1);
    color: var(--fill-6);
  }
  &.removed {
    grid-template-columns: $iconSize auto 1fr auto auto;
    height: $removedItemHeight;
    padding-top: $removedItemPadB;
    padding-bottom: $removedItemPadB;
  }
  &:not(.removed) {
    .script-buttons-left {
      min-width: 165px;
    }
    .script-buttons-right {
      min-width: 30px;
      justify-self: end;
    }
  }
  &.focused {
    // bring the focused item to the front so that the box-shadow will not be overlapped
    // by the next item
    z-index: 1;
    box-shadow: 1px 2px 9px var(--fill-7);
    &:focus {
      box-shadow: 1px 2px 9px var(--fill-9);
    }
  }
  .script-message {
    display: inline-block;
    max-width: 14em;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    vertical-align: bottom;
  }
  &.error {
    border-color: #f008;
    [*|href="#refresh"] {
      fill: #f00;
    }
    .script-message {
      color: #f00;
    }
  }
  &-info-1 {
    display: flex;
    gap: 8px;
    align-items: center;
    .script:not(.removed) & {
      align-self: flex-start;
    }
  }
  &-name {
    font-weight: 500;
    font-size: $nameFontSize;
    color: inherit;
    padding-left: .5rem;
    &.removed {
      margin-right: 8px;
    }
    &.disabled {
      color: var(--fill-8);
    }
  }
  &-tags {
    white-space: nowrap;
    a {
      margin-right: 4px;
      cursor: pointer;
      color: var(--fill-4);
      &:hover {
        color: var(--fill-6);
      }
    }
    .active {
      color: var(--fill-6);
      font-weight: bold;
    }
  }
  &-buttons {
    display: flex;
    align-items: center;
    line-height: 1;
    white-space: nowrap;
    color: hsl(215, 13%, 28%);
    @media (prefers-color-scheme: dark) {
      color: hsl(215, 10%, 55%);
    }
    .disabled {
      color: var(--fill-2);
      [data-hotkey]::after {
        content: none;
      }
    }
    .icon {
      display: block;
    }
    &-right {
      margin-left: 8px;
      text-align: right;
      .removed & {
        order: 2;
      }
    }
  }
  &-info {
    align-items: center;
    line-height: $itemLineHeight;
    margin-left: 8px;
    overflow: hidden; /* e.g. in recycle bin with a long author/version and multi-column */
    .removed & {
      order: 2;
    }
  }
  &-icon {
    grid-row-end: span 2;
    width: $iconSize;
    height: $iconSize;
    cursor: pointer;
    a {
      display: block;
    }
    img {
      display: block;
      width: 100%;
      height: 100%;
      &:not([src]) {
        visibility: hidden; // hiding the empty outline border while the image loads
      }
    }
    .disabled &,
    .removed & {
      img {
        filter: grayscale(.8);
        opacity: .5;
      }
    }
    .removed & {
      grid-row-end: auto;
      width: $iconSizeSmaller;
      height: $iconSizeSmaller;
    }
  }
  &-author {
    display: flex;
    align-items: center;
    min-width: 4em;
    > .ellipsis {
      display: inline-block;
      max-width: 15ch;
    }
  }
  &-message {
    white-space: nowrap;
  }
  .visit {
    color: var(--fill-8);
  }
}

.hotkeys [data-hotkey] {
  position: relative;
  &::after {
    content: attr(data-hotkey);
    position: absolute;
    left: 50%;
    bottom: 80%;
    transform-origin: bottom;
    transform: translate(-50%,0);
    padding: .2em;
    background: #fe6;
    color: #333;
    border: 1px solid #880;
    border-radius: .2em;
    font: .8rem monospace; // monospace usually provides differentiation between l and I, 0 and O
    line-height: 1;
  }
}

.scripts {
  display: flex;
  flex-wrap: wrap;
  align-content: flex-start;
  padding: 0 0 $itemMargin 0;
  &[data-table] {
    /* Copied from @common/ui/style/style.css and changed max-width */
    @media (max-width: 650px) {
      .hidden-sm {
        display: none !important;
      }
    }
    @media (max-width: 400px) {
      .hidden-xs {
        display: none !important;
      }
    }
    // --num-columns is set in tab-installed.vue
    --w: calc((100% - $itemMargin * (var(--num-columns) - 1)) / var(--num-columns));
    // when searching for text the items are shuffled so we can't use different margins on columns
    // TODO: make `sortedScripts` a computed property that only shows visible scripts?
    justify-content: space-between;
    &[data-columns="3"]::after { // left-aligning items in the last row
      width: calc(var(--w) - 1px); // subtracting 1px to match margin of `.script`
      content: '';
    }
    &[data-columns="1"], &[data-columns="3"] {
      .script:nth-child(even) {
        background-color: var(--fill-0-5);
      }
    }
    &[data-columns="2"] .script {
      &:nth-child(4n + 2),
      &:nth-child(4n + 3) {
        background-color: var(--fill-0-5);
      }
    }
    &[data-columns="4"] .script {
      &:nth-child(8n + 2),
      &:nth-child(8n + 4),
      &:nth-child(8n + 5),
      &:nth-child(8n + 7) {
        background-color: var(--fill-0-5);
      }
    }
    .script {
      grid-template-columns:
        auto /* main icons */
        auto /* trash icon */
        $iconSize /* script icon */
        minmax(15ch, 1fr) /* name */
        auto /* info */;
      align-items: center;
      height: 2.5rem;
      width: var(--w);
      margin: -1px 0 0 -1px;
      padding: 0 calc(2 * $itemMargin) 0 $itemMargin;
      border-radius: 0;
      background: none;
      &:hover::after {
        // using a separate element with z-index higher than a sibling's overlapped border
        content: '';
        position: absolute;
        top: -1px;
        left: -1px;
        right: -1px;
        bottom: -1px;
        border: 1px solid var(--fill-6);
        pointer-events: none;
        z-index: 2;
      }
      &-info-1 {
        display: flex;
        align-self: stretch;
        align-items: center;
      }
      &-icon {
        width: 2rem;
        height: 2rem;
        margin-left: .5rem;
        grid-row-end: auto;
      }
      &-info {
        order: 2;
        align-self: stretch;
        justify-content: end;
        margin-left: .5rem;
        line-height: 1.2; /* not using 1.1 as it cuts descender in "g" */
        .size {
          width: 3em;
          text-align: right;
        }
        .updated, .version, .visit {
          text-align: right;
          color: var(--fill-8);
        }
        .updated, .visit {
          width: 3em;
        }
        .version:not(:empty)::before {
          width: 6em;
          content: 'v';
        }
      }
      &-buttons {
        order: -1;
        margin: 0;
        &-left {
          > :first-child { /* edit button */
            display: none;
          }
        }
      }
      &.removed .script-buttons .sep {
        display: none;
      }
      &-message {
        position: absolute;
        right: .5em;
        top: 2em;
        z-index: 3;
        font-size: smaller;
        padding: 1px .5em;
        border-radius: .5em;
        border: 1px solid var(--fill-5);
        background: var(--bg);
      }
    }
  }
  &:not([data-table]) {
    [data-hotkey-table]::after {
      content: none;
    }
    .script:not(.removed) .size {
      position: absolute;
      bottom: 10px;
      right: 40px;
    }
    .script-icon {
      align-self: start;
    }
  }
  &[data-show-order] [data-order]::before {
    content: attr(data-order) '. ';
  }
}

svg[invert] {
  fill: transparent;
  stroke: currentColor;
  stroke-width: $strokeWidth;
}
.add-match-panel {
  grid-column: 1 / -1;
  display: flex;
  flex-direction: column;
  gap: .4rem;
  margin-top: .5rem;
  padding-top: .5rem;
  border-top: 1px solid var(--fill-3);
  input {
    width: 100%;
  }
  .add-match-chips,
  .add-match-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: .4rem;
    button {
      max-width: 100%;
    }
  }
  small {
    color: var(--fill-7);
  }
  .add-match-note {
    padding: .3rem .5rem;
    border-radius: 2px;
    background: hsl(0, 100%, 95%);
    color: #c00;
  }
}
</style>
